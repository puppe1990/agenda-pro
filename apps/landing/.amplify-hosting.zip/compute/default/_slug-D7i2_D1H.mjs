import { d as Link, f as notFound, m as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { c as formatPostDate, l as getAllBlogPosts, p as getBlogPostModule } from "./_ssr/blog-posts-D944OGVC.mjs";
import { t as Route } from "./_slug-tHQN0Wg2.mjs";
import { t as BlogChrome } from "./_ssr/BlogChrome-CrjkPVjg.mjs";
import { a as ArrowLeft } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-D7i2_D1H.js
var import_jsx_runtime = require_jsx_runtime();
function BlogArticle({ post, Content }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "landing-blog-article-wrap",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/blog",
			className: "landing-blog-back",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				size: 16,
				"aria-hidden": "true"
			}), "Voltar ao blog"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "landing-blog-article",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "landing-blog-article-header",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "Blog"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "landing-blog-article-title",
							children: post.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "landing-blog-article-meta",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
									dateTime: post.publishedAt,
									children: formatPostDate(post.publishedAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									className: "landing-blog-article-meta-dot",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: post.author })
							]
						}),
						post.tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "landing-blog-tags mt-4",
							"aria-label": "Tags do artigo",
							children: post.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "landing-blog-tag",
								children: tag
							}, tag))
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-blog-article-deck",
							children: post.description
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "landing-blog-article-body",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "landing-blog-article-footer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "landing-blog-article-footer-text",
						children: "Quer aplicar isso no seu negócio?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/blog",
						className: "btn-secondary px-5 py-2.5 no-underline",
						children: "Ver mais artigos"
					})]
				})
			]
		})]
	});
}
function BlogPostPage() {
	const { post } = Route.useLoaderData();
	const module = getBlogPostModule(post.slug);
	if (!module) throw notFound();
	const Content = module.default;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogChrome, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogArticle, {
		post,
		Content
	}) });
}
function getBlogStaticSlugs() {
	return getAllBlogPosts().map((post) => post.slug);
}
//#endregion
export { BlogPostPage as component, getBlogStaticSlugs };
