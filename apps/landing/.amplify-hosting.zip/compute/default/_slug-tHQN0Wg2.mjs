import { c as lazyRouteComponent, f as notFound, l as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
import { m as getLandingMeta, p as getBlogPostModule } from "./_ssr/blog-posts-D944OGVC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-tHQN0Wg2.js
var DEFAULT_LANDING_URL = "https://gestaobem.com";
var DEFAULT_OG_IMAGE_PATH = "/og-image.png";
function getLandingSiteUrl(envUrl, isDev) {
	const url = envUrl ?? "https://gestaobem.com";
	if (url) return url.replace(/\/$/, "");
	return isDev ?? false ? "http://localhost:3001" : DEFAULT_LANDING_URL;
}
function getAbsoluteUrl(path, siteUrl) {
	const normalizedPath = path.startsWith("/") ? path : `/${path}`;
	return `${siteUrl.replace(/\/$/, "")}${normalizedPath}`;
}
function getOgImageUrl(imagePath = DEFAULT_OG_IMAGE_PATH, siteUrl = getLandingSiteUrl()) {
	return getAbsoluteUrl(imagePath, siteUrl);
}
function buildSocialMetaTags(input, siteUrl = getLandingSiteUrl()) {
	const url = getAbsoluteUrl(input.path ?? "/", siteUrl);
	const image = getOgImageUrl(input.imagePath, siteUrl);
	return [
		{
			property: "og:type",
			content: input.type ?? "website"
		},
		{
			property: "og:site_name",
			content: getLandingMeta().title
		},
		{
			property: "og:locale",
			content: "pt_BR"
		},
		{
			property: "og:title",
			content: input.title
		},
		{
			property: "og:description",
			content: input.description
		},
		{
			property: "og:url",
			content: url
		},
		{
			property: "og:image",
			content: image
		},
		{
			property: "og:image:width",
			content: "1200"
		},
		{
			property: "og:image:height",
			content: "630"
		},
		{
			property: "og:image:alt",
			content: input.title
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		},
		{
			name: "twitter:title",
			content: input.title
		},
		{
			name: "twitter:description",
			content: input.description
		},
		{
			name: "twitter:image",
			content: image
		},
		{
			name: "twitter:image:alt",
			content: input.title
		}
	];
}
var $$splitComponentImporter = () => import("./_slug-D7i2_D1H.mjs");
var Route = createFileRoute("/blog/$slug")({
	loader: ({ params }) => {
		const module = getBlogPostModule(params.slug);
		if (!module) throw notFound();
		return { post: module.meta };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: ({ loaderData }) => {
		const post = loaderData?.post;
		if (!post) return { meta: [{ title: "Artigo não encontrado" }] };
		const title = `${post.title} | Gestão Bem`;
		return { meta: [
			{ title },
			{
				name: "description",
				content: post.description
			},
			...buildSocialMetaTags({
				title,
				description: post.description,
				path: `/blog/${post.slug}`,
				type: "article"
			})
		] };
	}
});
//#endregion
export { buildSocialMetaTags as n, Route as t };
