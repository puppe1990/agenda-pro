import { m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as LandingFooter, r as LandingHeader } from "./LandingChrome-DcTRQuv-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BlogChrome-CrjkPVjg.js
var import_jsx_runtime = require_jsx_runtime();
function BlogChrome({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page-wrap px-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingHeader, {}), children]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingFooter, {})] });
}
//#endregion
export { BlogChrome as t };
