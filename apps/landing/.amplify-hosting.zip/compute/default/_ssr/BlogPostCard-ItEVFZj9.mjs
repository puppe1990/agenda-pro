import { d as Link, m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as formatPostDate } from "./blog-posts-D944OGVC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BlogPostCard-ItEVFZj9.js
var import_jsx_runtime = require_jsx_runtime();
function BlogPostCard({ post }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "landing-blog-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "landing-blog-card-date",
				children: formatPostDate(post.publishedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "landing-blog-card-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/blog/$slug",
					params: { slug: post.slug },
					className: "landing-blog-card-link",
					children: post.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "landing-blog-card-description",
				children: post.description
			}),
			post.tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "landing-blog-tags",
				"aria-label": "Tags do artigo",
				children: post.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "landing-blog-tag",
					children: tag
				}, tag))
			}) : null
		]
	});
}
//#endregion
export { BlogPostCard as t };
