import { d as Link, m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as getAppUrl, g as getWhatsAppLinks, m as getLandingMeta, r as LANDING_FOOTER_LINKS, s as WHATSAPP_BUTTONS, u as getAppBaseUrl } from "./blog-posts-D944OGVC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/LandingChrome-DcTRQuv-.js
var import_jsx_runtime = require_jsx_runtime();
function LandingHeader() {
	const meta = getLandingMeta();
	const appUrl = getAppBaseUrl();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "landing-header-sticky",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "page-wrap px-4 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2.5 no-underline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--lagoon-deep)] text-sm font-bold text-white",
					children: "GB"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-bold text-[var(--sea-ink)]",
					children: meta.title
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Principal",
				className: "flex items-center gap-4 sm:gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/#recursos",
						className: "hidden sm:block text-sm font-semibold text-[var(--sea-ink-soft)] no-underline transition-colors hover:text-[var(--sea-ink)]",
						children: "Recursos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/#como-funciona",
						className: "hidden sm:block text-sm font-semibold text-[var(--sea-ink-soft)] no-underline transition-colors hover:text-[var(--sea-ink)]",
						children: "Como funciona"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/blog",
						className: "hidden sm:block text-sm font-semibold text-[var(--sea-ink-soft)] no-underline transition-colors hover:text-[var(--sea-ink)]",
						children: "Blog"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: getAppUrl("/signup", appUrl),
						className: "hidden sm:inline-flex btn-primary px-4 py-2 text-sm no-underline",
						children: "Começar grátis"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: getAppUrl("/login", appUrl),
						className: "btn-secondary px-4 py-2 text-sm no-underline",
						children: "Entrar"
					})
				]
			})]
		})
	});
}
function WhatsAppIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "landing-whatsapp-icon",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" })
	});
}
function FloatingWhatsApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "landing-whatsapp-stack",
		"aria-label": "Contato via WhatsApp",
		children: getWhatsAppLinks("5521987962324").map((link, index) => {
			const isPrimary = link.id === WHATSAPP_BUTTONS.at(-1)?.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: link.href,
				target: "_blank",
				rel: "noopener noreferrer",
				className: isPrimary ? "landing-whatsapp-btn" : "landing-whatsapp-btn landing-whatsapp-btn-secondary",
				"aria-label": link.ariaLabel,
				style: { animationDelay: `${index * 80}ms` },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), link.label]
			}, link.id);
		})
	});
}
function LandingFooter() {
	const meta = getLandingMeta();
	const appUrl = getAppBaseUrl();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer landing-footer",
		role: "contentinfo",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "page-wrap px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "landing-footer-grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--lagoon-deep)] text-sm font-bold text-white",
							children: "GB"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold text-[var(--sea-ink)]",
							children: meta.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm leading-relaxed text-[var(--sea-ink-soft)]",
						children: meta.footerTagline
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs font-bold uppercase tracking-wider text-[var(--sea-ink-soft)]",
						children: "Navegação"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid gap-2",
						children: LANDING_FOOTER_LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: link.href,
							className: "landing-footer-link",
							children: link.label
						}, link.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs font-bold uppercase tracking-wider text-[var(--sea-ink-soft)]",
						children: "Produto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: getAppUrl("/signup", appUrl),
								className: "landing-footer-link",
								children: "Criar conta grátis"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: getAppUrl("/login", appUrl),
								className: "landing-footer-link",
								children: "Entrar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: getAppUrl("/book/studio-demo", appUrl),
								className: "landing-footer-link",
								children: "Portal de agendamento"
							})
						]
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "landing-footer-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"© ",
					meta.copyrightYear,
					" ",
					meta.title,
					". Todos os direitos reservados."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Feito para salões, clínicas e consultórios." })]
			})]
		})
	});
}
//#endregion
export { LandingFooter as n, LandingHeader as r, FloatingWhatsApp as t };
