import { m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as getBlogIndexMeta, l as getAllBlogPosts } from "./blog-posts-D944OGVC.mjs";
import { t as BlogChrome } from "./BlogChrome-CrjkPVjg.mjs";
import { t as BlogPostCard } from "./BlogPostCard-ItEVFZj9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog-CZQavMII.js
var import_jsx_runtime = require_jsx_runtime();
function BlogIndexPage() {
	const meta = getBlogIndexMeta();
	const posts = getAllBlogPosts();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogChrome, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "landing-section pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "island-kicker mb-3",
				children: "Conteúdo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "landing-section-title",
				children: meta.heading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "landing-section-lead",
				children: meta.lead
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3",
				children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogPostCard, { post }, post.slug))
			})
		]
	}) });
}
//#endregion
export { BlogIndexPage as component };
