import { m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog-posts-D944OGVC.js
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var LANDING_FEATURES = [
	{
		id: "agenda",
		title: "Agenda inteligente",
		description: "Visão por dia ou semana, busca rápida e agendamento sem fricção."
	},
	{
		id: "crm",
		title: "CRM de clientes",
		description: "Histórico, notas e busca por nome ou telefone em segundos."
	},
	{
		id: "financeiro",
		title: "Financeiro integrado",
		description: "Receitas, despesas e lucro do mês no mesmo painel."
	},
	{
		id: "relatorios",
		title: "Relatórios claros",
		description: "Acompanhe desempenho e exporte dados quando precisar."
	}
];
var LANDING_STATS = [
	{
		id: "agendamentos",
		value: "2.400+",
		label: "Agendamentos por mês"
	},
	{
		id: "negocios",
		value: "180+",
		label: "Negócios ativos"
	},
	{
		id: "tempo",
		value: "3h",
		label: "Economizadas por semana"
	},
	{
		id: "satisfacao",
		value: "98%",
		label: "Satisfação dos clientes"
	}
];
var LANDING_STEPS = [
	{
		id: "cadastro",
		title: "Crie sua conta",
		description: "Cadastre seu negócio em minutos e configure serviços e horários."
	},
	{
		id: "agenda",
		title: "Organize a agenda",
		description: "Centralize agendamentos, confirmações e lembretes em um só lugar."
	},
	{
		id: "crescimento",
		title: "Acompanhe resultados",
		description: "Veja receitas, desempenho da equipe e exporte relatórios quando quiser."
	}
];
var LANDING_TESTIMONIALS = [
	{
		id: "marina",
		quote: "Antes eu perdia horas no caderno. Hoje a equipe agenda sozinha e eu foco no atendimento.",
		author: "Marina Costa",
		role: "Studio de estética, São Paulo"
	},
	{
		id: "rafael",
		quote: "O financeiro integrado mudou o jogo. Sei exatamente quanto entrou e saiu no mês.",
		author: "Dr. Rafael Mendes",
		role: "Consultório odontológico, Curitiba"
	},
	{
		id: "julia",
		quote: "Meus clientes agendam pelo link e recebem lembrete no WhatsApp. Menos faltas, mais receita.",
		author: "Júlia Almeida",
		role: "Salão de beleza, Belo Horizonte"
	}
];
var LANDING_FAQ = [
	{
		id: "preco",
		question: "Preciso pagar para começar?",
		answer: "Não. Você pode criar sua conta gratuitamente e explorar a plataforma antes de decidir."
	},
	{
		id: "equipe",
		question: "Posso adicionar minha equipe?",
		answer: "Sim. Convide profissionais, defina permissões e acompanhe comissões no painel."
	},
	{
		id: "whatsapp",
		question: "Funciona com WhatsApp?",
		answer: "Sim. Envie confirmações e lembretes com templates e links diretos para conversa."
	},
	{
		id: "portal",
		question: "Meus clientes agendam sozinhos?",
		answer: "Sim. Compartilhe seu link público e receba agendamentos 24 horas por dia."
	}
];
var LANDING_FOOTER_LINKS = [
	{
		id: "recursos",
		label: "Recursos",
		href: "#recursos"
	},
	{
		id: "como-funciona",
		label: "Como funciona",
		href: "#como-funciona"
	},
	{
		id: "depoimentos",
		label: "Depoimentos",
		href: "#depoimentos"
	},
	{
		id: "blog",
		label: "Blog",
		href: "/blog"
	},
	{
		id: "faq",
		label: "FAQ",
		href: "#faq"
	}
];
var WHATSAPP_BUTTONS = [{
	id: "suporte",
	label: "Suporte",
	message: "Olá! Preciso de ajuda com o Gestão Bem.",
	ariaLabel: "Falar com suporte pelo WhatsApp"
}, {
	id: "vendas",
	label: "Demonstração",
	message: "Olá! Gostaria de agendar uma demonstração do Gestão Bem.",
	ariaLabel: "Agendar demonstração pelo WhatsApp"
}];
var DEFAULT_APP_URL = "https://app.gestaobem.com";
function getAppBaseUrl(envUrl, isDev) {
	const url = envUrl ?? "https://app.gestaobem.com";
	if (url) return url;
	return isDev ?? false ? "http://localhost:3000" : DEFAULT_APP_URL;
}
function getAppUrl(path, appBaseUrl) {
	return `${appBaseUrl.replace(/\/$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
}
function getWhatsAppUrl(phone, message, baseUrl = "https://wa.me") {
	return `${baseUrl}/${phone.replace(/\D/g, "")}?${new URLSearchParams({ text: message }).toString()}`;
}
function getWhatsAppLinks(phone, buttons = WHATSAPP_BUTTONS) {
	return buttons.map((button) => ({
		...button,
		href: getWhatsAppUrl(phone, button.message)
	}));
}
function getLandingMeta() {
	return {
		title: "Gestão Bem",
		description: "Agenda, CRM e financeiro para salões, clínicas e consultórios.",
		kicker: "Para salões, clínicas e consultórios",
		headline: "Agenda, clientes e financeiro em um só lugar.",
		subheadline: "Substitua a agenda física, permita agendamento online e acompanhe o desempenho do seu negócio com relatórios claros.",
		ctaTitle: "Pronto para organizar seu negócio?",
		ctaDescription: "Comece grátis hoje e veja como é simples centralizar agenda, clientes e financeiro.",
		footerTagline: "Agenda, CRM e financeiro para negócios que crescem.",
		copyrightYear: (/* @__PURE__ */ new Date()).getFullYear()
	};
}
function sortPostsByDate(posts) {
	return [...posts].sort((left, right) => new Date(right.publishedAt).getTime() - new Date(left.publishedAt).getTime());
}
function getPostBySlug(posts, slug) {
	return posts.find((post) => post.slug === slug);
}
function getLatestPosts(posts, limit) {
	return sortPostsByDate(posts).slice(0, limit);
}
function formatPostDate(publishedAt, locale = "pt-BR") {
	return new Intl.DateTimeFormat(locale, {
		day: "2-digit",
		month: "long",
		year: "numeric",
		timeZone: "UTC"
	}).format(/* @__PURE__ */ new Date(`${publishedAt}T12:00:00.000Z`));
}
function getBlogIndexMeta() {
	return {
		title: "Blog | Gestão Bem",
		description: "Dicas de agenda, atendimento e gestão para salões, clínicas e consultórios.",
		heading: "Blog Gestão Bem",
		lead: "Conteúdo prático para organizar agenda, clientes e financeiro no dia a dia do seu negócio."
	};
}
var organizar_financeiro_do_salao_exports = /* @__PURE__ */ __exportAll({
	default: () => MDXContent$2,
	meta: () => meta$2
});
var meta$2 = {
	"slug": "organizar-financeiro-do-salao",
	"title": "Como organizar o financeiro do salão em um só painel",
	"description": "Separe entradas, saídas e comissões para enxergar o lucro real do mês sem planilhas paralelas.",
	"publishedAt": "2026-06-07",
	"author": "Equipe Gestão Bem",
	"tags": ["financeiro", "salão"]
};
function _createMdxContent$2(props) {
	const _components = {
		h2: "h2",
		p: "p",
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Muitos salões faturam bem, mas não sabem quanto sobra de verdade. O problema quase sempre é o mesmo: receitas em um lugar, despesas em outro." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Comece pelo básico do mês" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Registre todas as entradas ligadas a serviços e produtos. Em seguida, liste despesas fixas e variáveis: aluguel, insumos, marketing e comissões." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Conecte agenda e caixa" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Quando o agendamento vira receita automaticamente, você reduz esquecimentos e evita lançamentos duplicados no fim do dia." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Acompanhe comissões da equipe" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Defina regras claras por profissional e acompanhe o valor no mesmo painel. Isso evita surpresas na folha e melhora a conversa com a equipe." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Revise semanalmente" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Um check-in rápido toda semana corrige desvios antes que virem problema no fechamento do mês." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Centralizar agenda, clientes e financeiro elimina retrabalho e dá clareza para decidir com tranquilidade." })
	] });
}
function MDXContent$2(props = {}) {
	const { wrapper: MDXLayout } = props.components || {};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent$2, { ...props })
	}) : _createMdxContent$2(props);
}
var portal_de_agendamento_24h_exports = /* @__PURE__ */ __exportAll({
	default: () => MDXContent$1,
	meta: () => meta$1
});
var meta$1 = {
	"slug": "portal-de-agendamento-24h",
	"title": "Portal de agendamento 24h para seus clientes",
	"description": "Compartilhe um link público e receba reservas fora do horário comercial, sem depender de mensagens manuais.",
	"publishedAt": "2026-06-07",
	"author": "Equipe Gestão Bem",
	"tags": ["agenda", "clientes"]
};
function _createMdxContent$1(props) {
	const _components = {
		h2: "h2",
		p: "p",
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Seus clientes querem marcar horário quando lembram — muitas vezes à noite ou no fim de semana. Um portal de agendamento resolve isso sem aumentar sua carga de atendimento." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "O que o cliente precisa ver" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Horários disponíveis, serviços com duração clara e confirmação imediata. Quanto menos passos, maior a conversão." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Menos mensagens soltas" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Com link único do negócio, você reduz o vai-e-volta no WhatsApp e mantém a agenda sempre atualizada." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Combine com lembretes" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Depois da reserva, envie confirmação e lembrete automático. O cliente se sente cuidado e você reduz faltas." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "Divulgue nos canais certos" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Bio do Instagram, mensagem automática do WhatsApp e QR Code na recepção ajudam a transformar visitantes em agendamentos." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Um portal bem configurado trabalha por você enquanto a equipe foca no atendimento presencial." })
	] });
}
function MDXContent$1(props = {}) {
	const { wrapper: MDXLayout } = props.components || {};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent$1, { ...props })
	}) : _createMdxContent$1(props);
}
var reduzir_faltas_na_agenda_exports = /* @__PURE__ */ __exportAll({
	default: () => MDXContent,
	meta: () => meta
});
var meta = {
	"slug": "reduzir-faltas-na-agenda",
	"title": "5 formas de reduzir faltas na agenda",
	"description": "Confirmações, lembretes e políticas simples para diminuir horários vazios no seu negócio.",
	"publishedAt": "2026-06-07",
	"author": "Equipe Gestão Bem",
	"tags": ["agenda", "whatsapp"]
};
function _createMdxContent(props) {
	const _components = {
		h2: "h2",
		p: "p",
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Horários vazios custam caro. A boa notícia é que pequenas mudanças na rotina já reduzem faltas sem complicar o atendimento." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "1. Confirme com antecedência" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Envie uma confirmação 24 horas antes do horário. Mensagens curtas e objetivas funcionam melhor do que textos longos." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "2. Use lembretes automáticos" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Combine confirmação com lembrete no dia do atendimento. O cliente lembra do compromisso e você evita imprevistos." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "3. Facilite o reagendamento" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Quando for simples remarcar, menos pessoas simplesmente somem. Ofereça um link direto para escolher outro horário." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "4. Registre o histórico do cliente" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Clientes com histórico de faltas podem receber confirmação reforçada ou sinal antecipado, sem constrangimento." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, { children: "5. Analise os horários críticos" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Identifique dias e faixas com mais ausências. Ajuste a oferta de horários ou reforce a comunicação nesses períodos." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Com agenda centralizada e WhatsApp integrado, você aplica essas práticas em minutos — não em planilhas." })
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = props.components || {};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var postModules = /* #__PURE__ */ Object.assign({
	"../../content/blog/organizar-financeiro-do-salao.mdx": organizar_financeiro_do_salao_exports,
	"../../content/blog/portal-de-agendamento-24h.mdx": portal_de_agendamento_24h_exports,
	"../../content/blog/reduzir-faltas-na-agenda.mdx": reduzir_faltas_na_agenda_exports
});
function getModules() {
	return Object.values(postModules);
}
function getAllBlogPosts() {
	return sortPostsByDate(getModules().map((module) => module.meta));
}
function getBlogPostModule(slug) {
	const post = getPostBySlug(getAllBlogPosts(), slug);
	if (!post) return;
	return getModules().find((module) => module.meta.slug === post.slug);
}
//#endregion
export { LANDING_STEPS as a, formatPostDate as c, getAppUrl as d, getBlogIndexMeta as f, getWhatsAppLinks as g, getLatestPosts as h, LANDING_STATS as i, getAllBlogPosts as l, getLandingMeta as m, LANDING_FEATURES as n, LANDING_TESTIMONIALS as o, getBlogPostModule as p, LANDING_FOOTER_LINKS as r, WHATSAPP_BUTTONS as s, LANDING_FAQ as t, getAppBaseUrl as u };
