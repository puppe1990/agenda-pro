//#region node_modules/.nitro/vite/services/ssr/assets/empty-plugin-adapters-DQn46CI2.js
var pluginSerializationAdapters = [];
var hasPluginAdapters = false;
//#endregion
export { hasPluginAdapters, pluginSerializationAdapters };
