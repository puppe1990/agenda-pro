import { c as lazyRouteComponent, i as HeadContent, l as createFileRoute, m as require_jsx_runtime, o as createRouter, r as Scripts, s as Outlet, u as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as getBlogIndexMeta, m as getLandingMeta } from "./blog-posts-D944OGVC.mjs";
import { n as buildSocialMetaTags, t as Route$3 } from "../_slug-tHQN0Wg2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DgTayY08.js
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-COx5uLk4.css";
var Route$2 = createRootRoute({
	head: () => {
		const meta = getLandingMeta();
		return {
			meta: [
				{ charSet: "utf-8" },
				{
					name: "viewport",
					content: "width=device-width, initial-scale=1"
				},
				{ title: meta.title },
				{
					name: "description",
					content: meta.description
				},
				{
					name: "theme-color",
					content: "#be123c"
				}
			],
			links: [
				{
					rel: "stylesheet",
					href: styles_default
				},
				{
					rel: "manifest",
					href: "/manifest.json"
				},
				{
					rel: "icon",
					href: "/favicon.ico",
					sizes: "any"
				},
				{
					rel: "icon",
					type: "image/png",
					sizes: "32x32",
					href: "/favicon-32x32.png"
				},
				{
					rel: "icon",
					type: "image/png",
					sizes: "16x16",
					href: "/favicon-16x16.png"
				},
				{
					rel: "apple-touch-icon",
					href: "/apple-touch-icon.png"
				}
			]
		};
	},
	component: RootComponent
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "font-sans antialiased [overflow-wrap:anywhere]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})]
		})]
	});
}
var $$splitComponentImporter$1 = () => import("./routes-BvkML3Oy.mjs");
var Route$1 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => {
		const meta = getLandingMeta();
		return { meta: [
			{ title: meta.title },
			{
				name: "description",
				content: meta.description
			},
			...buildSocialMetaTags({
				title: meta.title,
				description: meta.description,
				path: "/"
			})
		] };
	}
});
var $$splitComponentImporter = () => import("./blog-CZQavMII.mjs");
var Route = createFileRoute("/blog/")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => {
		const meta = getBlogIndexMeta();
		return { meta: [
			{ title: meta.title },
			{
				name: "description",
				content: meta.description
			},
			...buildSocialMetaTags({
				title: meta.title,
				description: meta.description,
				path: "/blog"
			})
		] };
	}
});
var IndexRoute = Route$1.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$2
});
var BlogIndexRoute = Route.update({
	id: "/blog/",
	path: "/blog/",
	getParentRoute: () => Route$2
});
var rootRouteChildren = {
	IndexRoute,
	BlogSlugRoute: Route$3.update({
		id: "/blog/$slug",
		path: "/blog/$slug",
		getParentRoute: () => Route$2
	}),
	BlogIndexRoute
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	return createRouter({
		routeTree,
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 0
	});
}
//#endregion
export { getRouter };
