import { d as Link, m as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LANDING_STEPS, d as getAppUrl, h as getLatestPosts, i as LANDING_STATS, l as getAllBlogPosts, m as getLandingMeta, n as LANDING_FEATURES, o as LANDING_TESTIMONIALS, t as LANDING_FAQ, u as getAppBaseUrl } from "./blog-posts-D944OGVC.mjs";
import { n as LandingFooter, r as LandingHeader, t as FloatingWhatsApp } from "./LandingChrome-DcTRQuv-.mjs";
import { i as Calendar, n as Users, r as ChartColumn, t as Wallet } from "../_libs/lucide-react.mjs";
import { t as BlogPostCard } from "./BlogPostCard-ItEVFZj9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BvkML3Oy.js
var import_jsx_runtime = require_jsx_runtime();
var featureIcons = {
	agenda: Calendar,
	crm: Users,
	financeiro: Wallet,
	relatorios: ChartColumn
};
var testimonialColors = [
	"#be123c",
	"#0369a1",
	"#7c3aed"
];
function HeroVisual() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hero-preview-wrap",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hero-preview-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-preview-header",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hero-preview-dot",
							style: { background: "#f87171" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hero-preview-dot",
							style: { background: "#fbbf24" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hero-preview-dot",
							style: { background: "#34d399" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hero-preview-title",
							children: "Gestão Bem · Hoje"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-preview-body",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-slot hero-slot-booked",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-slot-time",
								children: "09:00"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-slot-content",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-name",
									children: "Marina Costa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-service",
									children: "Corte + Escova · 45min"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-slot hero-slot-free",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-slot-time",
								children: "10:00"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hero-slot-content",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-free-text",
									children: "Disponível"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-slot hero-slot-booked",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-slot-time",
								children: "11:00"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-slot-content",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-name",
									children: "Rafael Mendes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-service",
									children: "Barba · 30min"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-slot hero-slot-free",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-slot-time",
								children: "14:00"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hero-slot-content",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-free-text",
									children: "Disponível"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-slot hero-slot-booked",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-slot-time",
								children: "15:00"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-slot-content",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-name",
									children: "Júlia Santos"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hero-slot-service",
									children: "Manicure · 60min"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hero-preview-footer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hero-preview-new-btn",
						children: "+ Novo agendamento"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hero-notification",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hero-notification-dot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hero-notification-title",
				children: "Confirmado!"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hero-notification-sub",
				children: "Marina · hoje às 09:00"
			})] })]
		})]
	});
}
function LandingPage() {
	const appUrl = getAppBaseUrl();
	const meta = getLandingMeta();
	const latestPosts = getLatestPosts(getAllBlogPosts(), 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "page-wrap px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "landing-hero",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "landing-hero-grid",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "landing-hero-content rise-in",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "island-kicker mb-4",
									children: meta.kicker
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "display-title mb-5 max-w-3xl text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl",
									children: meta.headline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-8 max-w-xl text-base leading-relaxed text-[var(--sea-ink-soft)] sm:text-lg",
									children: meta.subheadline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: getAppUrl("/signup", appUrl),
										className: "btn-primary px-6 py-3 no-underline",
										children: "Começar grátis"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: getAppUrl("/login", appUrl),
										className: "btn-secondary px-6 py-3 no-underline",
										children: "Entrar"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroVisual, {})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "landing-section",
					"aria-label": "Números do produto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "landing-stat-band",
						children: LANDING_STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "landing-stat-item",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "landing-stat-value",
								children: stat.value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "landing-stat-label",
								children: stat.label
							})]
						}, stat.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "recursos",
					className: "landing-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "Recursos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: "Tudo que seu negócio precisa no dia a dia"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-section-lead",
							children: "Do primeiro agendamento ao fechamento do mês, o Gestão Bem conecta operação, clientes e financeiro em um fluxo simples."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2",
							children: LANDING_FEATURES.map((feature) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "landing-feature",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--lagoon-deep)]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(featureIcons[feature.id] ?? Calendar, { size: 22 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mb-1.5 text-base font-bold text-[var(--sea-ink)]",
											children: feature.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm leading-relaxed text-[var(--sea-ink-soft)]",
											children: feature.description
										})
									]
								}, feature.id);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "como-funciona",
					className: "landing-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "Como funciona"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: "Em três passos você está no ar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-section-lead",
							children: "Sem planilhas, sem caderno e sem depender de mensagens soltas no WhatsApp para organizar a rotina."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "landing-steps-grid mt-8 grid gap-4 md:grid-cols-3",
							children: LANDING_STEPS.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "landing-step",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "landing-step-number",
										children: index + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mb-2 text-base font-bold text-[var(--sea-ink)]",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm leading-relaxed text-[var(--sea-ink-soft)]",
										children: step.description
									})
								]
							}, step.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "depoimentos",
					className: "landing-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "Depoimentos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: "Quem usa, recomenda"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-section-lead",
							children: "Negócios de diferentes segmentos já simplificaram agenda, atendimento e controle financeiro com o Gestão Bem."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 md:grid-cols-3",
							children: LANDING_TESTIMONIALS.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "landing-testimonial",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "landing-testimonial-quote",
									children: [
										"\"",
										item.quote,
										"\""
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
									className: "testimonial-footer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "testimonial-avatar",
										style: { background: testimonialColors[idx % testimonialColors.length] },
										children: item.author[0]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "landing-testimonial-author",
										children: item.author
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "landing-testimonial-role",
										children: item.role
									})] })]
								})]
							}, item.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "blog",
					className: "landing-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "Blog"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: "Dicas para organizar seu negócio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-section-lead",
							children: "Artigos práticos sobre agenda, clientes e financeiro para salões, clínicas e consultórios."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3",
							children: latestPosts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogPostCard, { post }, post.slug))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/blog",
								className: "btn-secondary px-5 py-2.5 no-underline",
								children: "Ver todos os artigos"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "faq",
					className: "landing-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "island-kicker mb-3",
							children: "FAQ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: "Perguntas frequentes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-3",
							children: LANDING_FAQ.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "landing-faq-item",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "landing-faq-question",
									children: item.question
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "landing-faq-answer",
									children: item.answer
								})]
							}, item.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "landing-section",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "landing-cta-band text-center md:text-left md:flex md:items-center md:justify-between md:gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "landing-section-title",
							children: meta.ctaTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "landing-section-lead mx-auto md:mx-0",
							children: meta.ctaDescription
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex shrink-0 flex-wrap justify-center gap-3 md:mt-0 md:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: getAppUrl("/signup", appUrl),
								className: "btn-primary px-6 py-3 no-underline",
								children: "Começar grátis"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: getAppUrl("/login", appUrl),
								className: "btn-secondary-white px-6 py-3 no-underline",
								children: "Já tenho conta"
							})]
						})]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingFooter, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingWhatsApp, {})
	] });
}
//#endregion
export { LandingPage as component };
