//#region node_modules/.nitro/vite/services/ssr/assets/start-D--mZ5Hr.js
var startInstance = void 0;
//#endregion
export { startInstance };
