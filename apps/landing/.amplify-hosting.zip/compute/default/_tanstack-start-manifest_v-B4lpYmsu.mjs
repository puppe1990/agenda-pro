//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B4lpYmsu.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/matheuspuppe/Desktop/Projetos/agenda_pro/apps/landing/src/routes/__root.tsx",
		children: [
			"/",
			"/blog/$slug",
			"/blog/"
		],
		preloads: ["/assets/index-DI5iaIVT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DI5iaIVT.js"
		} }]
	},
	"/": {
		filePath: "/Users/matheuspuppe/Desktop/Projetos/agenda_pro/apps/landing/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cf-ccrai.js",
			"/assets/BlogPostCard-CTudnfWB.js",
			"/assets/LandingChrome-Bpw_sqdI.js",
			"/assets/createLucideIcon-XTx56FLY.js"
		]
	},
	"/blog/$slug": {
		filePath: "/Users/matheuspuppe/Desktop/Projetos/agenda_pro/apps/landing/src/routes/blog/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-D-XpyhQi.js",
			"/assets/BlogChrome-BpL4Lcrk.js",
			"/assets/createLucideIcon-XTx56FLY.js"
		]
	},
	"/blog/": {
		filePath: "/Users/matheuspuppe/Desktop/Projetos/agenda_pro/apps/landing/src/routes/blog/index.tsx",
		children: void 0,
		preloads: [
			"/assets/blog-CIU_sMJ9.js",
			"/assets/BlogChrome-BpL4Lcrk.js",
			"/assets/BlogPostCard-CTudnfWB.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
