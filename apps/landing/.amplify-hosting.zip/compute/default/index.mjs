globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as toNodeHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { Server } from "node:http";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region ../../node_modules/.pnpm/nitro-nightly@3.0.1-20260605-145636-4ab22a9d_@electric-sql+pglite@0.3.16_@libsql+client_b08965282426a743c060d2c43ec31516/node_modules/nitro-nightly/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"1fc1-lNOxSPFoPxiSdXpsK2aLx1brLXs\"",
		"mtime": "2026-06-07T23:17:56.230Z",
		"size": 8129,
		"path": "../../static/apple-touch-icon.png"
	},
	"/favicon-16x16.png": {
		"type": "image/png",
		"etag": "\"239-7LoR4w7XFQmljqwZD5eI+G8v08o\"",
		"mtime": "2026-06-07T23:17:56.230Z",
		"size": 569,
		"path": "../../static/favicon-16x16.png"
	},
	"/favicon-32x32.png": {
		"type": "image/png",
		"etag": "\"3ac-miaxqEDO3zn1B3yz9SqAg47P3CI\"",
		"mtime": "2026-06-07T23:17:56.231Z",
		"size": 940,
		"path": "../../static/favicon-32x32.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"3aee-YeZTO+Umk4vH0DFfojXdcmU+OIY\"",
		"mtime": "2026-06-07T23:17:56.231Z",
		"size": 15086,
		"path": "../../static/favicon.ico"
	},
	"/icon-192.png": {
		"type": "image/png",
		"etag": "\"22db-VYd8SLg2yKKbm2rQaG9S87uCyZk\"",
		"mtime": "2026-06-07T23:17:56.231Z",
		"size": 8923,
		"path": "../../static/icon-192.png"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"9faa-bERA99eL8LIelgUxWIuxp0StsHU\"",
		"mtime": "2026-06-07T23:17:56.231Z",
		"size": 40874,
		"path": "../../static/icon-512.png"
	},
	"/logo192.png": {
		"type": "image/png",
		"etag": "\"22db-wLxpF/PxIyb3X8QAWDImVfqZ0EM\"",
		"mtime": "2026-06-07T23:17:56.232Z",
		"size": 8923,
		"path": "../../static/logo192.png"
	},
	"/logo512.png": {
		"type": "image/png",
		"etag": "\"9faa-nTGLsoozg1pwE1Vb+ihSGNEqR84\"",
		"mtime": "2026-06-07T23:17:56.232Z",
		"size": 40874,
		"path": "../../static/logo512.png"
	},
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"20c-dTwYvx/glIN16SRxnNmWTbWvIds\"",
		"mtime": "2026-06-07T23:17:56.232Z",
		"size": 524,
		"path": "../../static/manifest.json"
	},
	"/og-image.png": {
		"type": "image/png",
		"etag": "\"1b959-P3K2w5iXUScnbujIuZKmefH3828\"",
		"mtime": "2026-06-07T23:17:56.233Z",
		"size": 112985,
		"path": "../../static/og-image.png"
	},
	"/og-image.svg": {
		"type": "image/svg+xml",
		"etag": "\"a57-FJcjj7FVB8kLsp6ibzhNxvX0cK8\"",
		"mtime": "2026-06-07T23:17:56.231Z",
		"size": 2647,
		"path": "../../static/og-image.svg"
	},
	"/assets/BlogChrome-BpL4Lcrk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11d-heSSxifBMEG2j5MYoPxlzf5CSNI\"",
		"mtime": "2026-06-07T23:17:54.331Z",
		"size": 285,
		"path": "../../static/assets/BlogChrome-BpL4Lcrk.js"
	},
	"/assets/BlogPostCard-CTudnfWB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2aa-gGoI7BZLXy7k1VHHS5KmIACG1J8\"",
		"mtime": "2026-06-07T23:17:54.331Z",
		"size": 682,
		"path": "../../static/assets/BlogPostCard-CTudnfWB.js"
	},
	"/assets/LandingChrome-Bpw_sqdI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13af-VrJGCXrjuvYZ97pZ3xFvvWLn/h0\"",
		"mtime": "2026-06-07T23:17:54.331Z",
		"size": 5039,
		"path": "../../static/assets/LandingChrome-Bpw_sqdI.js"
	},
	"/assets/_slug-D-XpyhQi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"790-g7i6rKqNEO/00b22xlBShvtdRD4\"",
		"mtime": "2026-06-07T23:17:54.331Z",
		"size": 1936,
		"path": "../../static/assets/_slug-D-XpyhQi.js"
	},
	"/assets/blog-CIU_sMJ9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27d-zXZBSQDh6rGTYQbgV+Wd7uudYa8\"",
		"mtime": "2026-06-07T23:17:54.332Z",
		"size": 637,
		"path": "../../static/assets/blog-CIU_sMJ9.js"
	},
	"/assets/createLucideIcon-XTx56FLY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49c-UW/YTMVOtqVijXsNxlX78reFpn8\"",
		"mtime": "2026-06-07T23:17:54.332Z",
		"size": 1180,
		"path": "../../static/assets/createLucideIcon-XTx56FLY.js"
	},
	"/assets/routes-Cf-ccrai.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26c5-5umee4RJQpasiX0ELFry/Gm7Ha4\"",
		"mtime": "2026-06-07T23:17:54.332Z",
		"size": 9925,
		"path": "../../static/assets/routes-Cf-ccrai.js"
	},
	"/assets/styles-COx5uLk4.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"a08f-BcTQXFq+kyLqGSoWZkLHtOmBjEA\"",
		"mtime": "2026-06-07T23:17:54.332Z",
		"size": 41103,
		"path": "../../static/assets/styles-COx5uLk4.css"
	},
	"/assets/index-DI5iaIVT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50436-g6xmzrI1q1Mn1rpDeaUagTcNm8I\"",
		"mtime": "2026-06-07T23:17:54.331Z",
		"size": 328758,
		"path": "../../static/assets/index-DI5iaIVT.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region ../../node_modules/.pnpm/nitro-nightly@3.0.1-20260605-145636-4ab22a9d_@electric-sql+pglite@0.3.16_@libsql+client_b08965282426a743c060d2c43ec31516/node_modules/nitro-nightly/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_f853KH = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_f853KH
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region ../../node_modules/.pnpm/nitro-nightly@3.0.1-20260605-145636-4ab22a9d_@electric-sql+pglite@0.3.16_@libsql+client_b08965282426a743c060d2c43ec31516/node_modules/nitro-nightly/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region ../../node_modules/.pnpm/nitro-nightly@3.0.1-20260605-145636-4ab22a9d_@electric-sql+pglite@0.3.16_@libsql+client_b08965282426a743c060d2c43ec31516/node_modules/nitro-nightly/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region ../../node_modules/.pnpm/nitro-nightly@3.0.1-20260605-145636-4ab22a9d_@electric-sql+pglite@0.3.16_@libsql+client_b08965282426a743c060d2c43ec31516/node_modules/nitro-nightly/dist/presets/aws-amplify/runtime/aws-amplify.mjs
new Server(toNodeHandler(useNitroApp().fetch)).listen(3e3, (err) => {
	if (err) console.error(err);
	else console.log(`Listening on http://localhost:3000 (AWS Amplify Hosting)`);
});
//#endregion
export {};
